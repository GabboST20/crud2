		function mostrarOpcion(itemSeleccionado,id){

			if(id==1){ /*Bloqueante*/
				$("#auxIcon").attr("class", "glyphicon glyphicon-ban-circle");
			}else if(id==2){
				/*Imporante*/
				$("#auxIcon").attr("class", "glyphicon glyphicon-warning-sign");
			}else if(id==3){
				/*Baja*/
				$("#auxIcon").attr("class", "glyphicon glyphicon-minus-sign");
			}
			$("#inputPriority").attr("value",itemSeleccionado);
		}
		