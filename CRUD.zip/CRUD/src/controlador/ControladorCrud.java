package controlador;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.ModeloUsuario;
import modelo.Usuario;

/**
 * Servlet implementation class ControladorCrud
 */
@WebServlet("/ControladorCrud")
public class ControladorCrud extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ModeloUsuario modelUsuario = new ModeloUsuario();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// leer el parametro que llega desde el form (Instruccion de formulario)
		String elComando = request.getParameter("accion") == null ? "x" : request.getParameter("accion");

		switch (elComando) {

		case "crear":
			try {
				agregarUsuario(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case "cargar":
			try {
				cargarUsuario(request,response);
			}catch(Exception e) {
				e.printStackTrace();
			}
			break;
			
		case "actualizar":
			try {
				actualizarUsuario(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
			break;

		case "borrar":
			try {
				borrarUsuario(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		default:
			listarUsuarios(request, response);
		}

	}
	
	private void cargarUsuario(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(request.getParameter("id"));		
		Usuario user = modelUsuario.cargarUsuario(id);
		
		// agregar la lista de productos al request
		request.setAttribute("usuarioCargado", user);

		// enviar ese request al jsp
		RequestDispatcher miDispatcher = request.getRequestDispatcher("/formActualizar.jsp");
		miDispatcher.forward(request, response);
	}

	protected void agregarUsuario(HttpServletRequest request, HttpServletResponse response)throws Exception{
		String nombre = (String) request.getParameter("nombre");
		String usuario = (String) request.getParameter("usuario");
				
		modelUsuario.crearUSuario(nombre, usuario);
		listarUsuarios(request, response);
		
	}
	
	protected void actualizarUsuario(HttpServletRequest request, HttpServletResponse response)throws Exception{
		int id = Integer.parseInt(request.getParameter("id")); 
		String nombre = (String) request.getParameter("nombre");
		String usuario = (String) request.getParameter("usuario");
				
		modelUsuario.actualizarUsuario(id, nombre, usuario);
		listarUsuarios(request, response);	
	}
	
	protected void borrarUsuario(HttpServletRequest request, HttpServletResponse response)throws Exception{
		int id = Integer.parseInt(request.getParameter("id")); 
				
		modelUsuario.eliminarUsuario(id);
		listarUsuarios(request, response);	
	}
	
	protected void listarUsuarios(HttpServletRequest request, HttpServletResponse response){
		List<Usuario> usuarios;

		try {
			//obtiene la lista de usuario
			usuarios = modelUsuario.getUsuarios();

			// agregar la lista de productos al request
			request.setAttribute("usuarios", usuarios);

			// enviar ese request al jsp
			RequestDispatcher miDispatcher = request.getRequestDispatcher("/vistaCrud.jsp");
			miDispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}	
	

}
