package modelo;

import java.sql.*;
import javax.annotation.Resource;
import javax.sql.*;

public class Conexion {
	
	private static Connection conexion =null;
	private final static String Cadena_bd="jdbc:mysql://localhost:3306/crud";
	
	public static Connection Conectar() {
		
		
			try {	
			 // Cargar el driver
	          Class.forName("com.mysql.jdbc.Driver");
	            
	          conexion=DriverManager.getConnection(Cadena_bd,"root","");
			}catch(Exception e) {
				System.out.println("error al conectar con bbdd ->"+e.getMessage());
				try {
					conexion.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}			
			}			
		
		
		return conexion;
				
	}
	
	public void Desconectar() {
		try {
			conexion.close();
		}catch(Exception e) {
			e.printStackTrace();			
		}
	}
}
