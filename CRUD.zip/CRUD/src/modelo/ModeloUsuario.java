package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class ModeloUsuario {
	private Usuario user;
	private static Conexion conexion;
	public List<Usuario> usuarios;
	
	/*Metodo que actualizar*/
	public void actualizarUsuario(int id, String nombreNew , String usuarioNew) {		
		Connection miConexion = null;
		PreparedStatement consulta = null;
		
		try {
			miConexion=conexion.Conectar();			
			consulta = miConexion.prepareStatement("UPDATE USUARIO SET NOMBRE = ? , USUARIO = ? WHERE ID = ?");
			consulta.setString(1, nombreNew);
			consulta.setString(2, usuarioNew);
			consulta.setInt(3, id);
			consulta.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
				conexion.Desconectar();			
		}finally {
			if(miConexion != null) {
				try {
					miConexion.close();
					consulta.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}		
	}

	
	/*MEtodo que devuelve el usuario a actualizar*/
	public Usuario cargarUsuario(int id) {
		Connection miConexion = null;
		PreparedStatement consulta = null;
		ResultSet rs= null;
		
		try {
			miConexion=conexion.Conectar();			
			consulta = miConexion.prepareStatement("select * from usuario where id = ?");
			consulta.setInt(1, id);
			rs = consulta.executeQuery();			
			while(rs.next()) {				
				 user = new Usuario();
				 user.setId(rs.getInt("id"));
				 user.setNombre(rs.getString("nombre"));
				 user.setUsuario(rs.getString("usuario"));
			}					
		}catch(Exception e) {
			e.printStackTrace();
				conexion.Desconectar();			
		}finally {
			if(miConexion != null) {
				try {
					miConexion.close();
					consulta.close();
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}
		return user;
		
	}	
	
	/*MEtodo que devuelve todos los usuario a listar*/
	public List<Usuario> getUsuarios() {		
		Connection miConexion = null;
		Statement consulta = null;
		ResultSet rs= null;
		
		try {
			usuarios = new ArrayList<>();
			miConexion=conexion.Conectar();			
			consulta = miConexion.createStatement();
			rs = consulta.executeQuery("select * from usuario");			
			while(rs.next()) {				
				 user = new Usuario();
				 user.setId(rs.getInt("id"));
				 user.setNombre(rs.getString("nombre"));
				 user.setUsuario(rs.getString("usuario"));
				
				 usuarios.add(user);				
			}					
		}catch(Exception e) {
			e.printStackTrace();
				conexion.Desconectar();			
		}finally {
			if(miConexion != null) {
				try {
					miConexion.close();
					consulta.close();
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}
		return usuarios;
		
	}

	/*MEtodo el cual eliminara*/
	public void eliminarUsuario(int id) {		
		Connection miConexion = null;
		PreparedStatement consulta = null;
		ResultSet rs= null;
		
		try {
			usuarios = new ArrayList<>();
			miConexion=conexion.Conectar();			
			consulta = miConexion.prepareStatement("delete from USUARIO WHERE ID = ?");
			consulta.setInt(1, id);
			consulta.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
				conexion.Desconectar();			
		}finally {
			if(miConexion != null) {
				try {
					miConexion.close();
					consulta.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}		
	}


	/*Metodo que creara Usuario*/
	public void crearUSuario(String nombre, String usuario) {		
		Connection miConexion = null;
		PreparedStatement consulta = null;		

		try {
			miConexion=conexion.Conectar();			
			consulta = miConexion.prepareStatement("insert into usuario (nombre, usuario) values (? , ?) ");
			consulta.setString(1, nombre);
			consulta.setString(2, usuario);
			consulta.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
			conexion.Desconectar();			
		}finally {
			if(miConexion != null) {
				try {
					miConexion.close();
					consulta.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}		
	}
	
	
}
